from __future__ import annotations
import copy, math
import numpy as np
from scipy.optimize import brentq, minimize_scalar
from scipy.integrate import solve_ivp
from scipy.special import erfinv

F = 96485.33212
R_GAS = 8.314462618

# ---------- Thermodynamics and particle distribution ----------

def compute_regular_solution_limits(omega_rt: float):
    """Spinodal and binodal compositions of a symmetric regular solution."""
    if omega_rt <= 2:
        return dict(xs1=np.nan, xs2=np.nan, xalpha=np.nan, xbeta=np.nan)
    disc = math.sqrt(1 - 2 / omega_rt)
    xs1, xs2 = (1-disc)/2, (1+disc)/2
    f = lambda x: math.log(x/(1-x)) + omega_rt*(1-2*x)
    eps = 1e-12
    xa = brentq(f, eps, xs1-eps)
    xb = brentq(f, xs2+eps, 1-eps)
    return dict(xs1=xs1, xs2=xs2, xalpha=xa, xbeta=xb)


def omega_rt_from_particle_radius(radius_m):
    """Particle-size-dependent Omega/(kBT), following Zelic & Katrasnik (2019).

    Zelic & Katrasnik define the characteristic C3 particle length
        L = 3.6338 V_p/A_p.
    The present model stores an equivalent spherical radius R; for a sphere
    V/A=R/3, hence L=1.2112667 R. Their Eqs. (16)-(17) relate the nucleation
    barrier Delta phi/kBT = -31.4435 nm/L + 1.42925 to the regular-solution
    barrier. Particles with L < 22 nm are assigned Omega=0, as in the paper.

    The conversion from equivalent spherical R to C3 L is a modeling mapping,
    not a measured particle-shape parameter.
    """
    R = np.atleast_1d(np.asarray(radius_m, dtype=float))
    out = np.zeros_like(R)
    for k, r in enumerate(R):
        L_nm = 1.2112666666666667 * r * 1e9
        if L_nm < 22.0:
            out[k] = 0.0
            continue
        target = -31.4435 / L_nm + 1.42925
        if target <= 0:
            out[k] = 0.0
            continue
        # Half the difference between symmetric spinodal chemical potentials.
        def barrier(w):
            d = math.sqrt(1 - 2/w)
            xs1 = (1-d)/2
            return math.log(xs1/(1-xs1)) + w*(1-2*xs1)
        out[k] = brentq(lambda w: barrier(w)-target, 2+1e-10, 10.0)
    return float(out[0]) if np.ndim(radius_m) == 0 else out


def build_psd(r_mean: float, cv: float, n: int):
    """Deterministic lognormal number distribution and volume weights."""
    if n == 1 or cv == 0:
        return dict(R=np.array([r_mean]), w_number=np.array([1.0]),
                    w_volume=np.array([1.0]), R_number_mean=r_mean,
                    R_volume_mean=r_mean, cv=0.0)
    sigma_ln = math.sqrt(math.log(1 + cv**2))
    mu_ln = math.log(r_mean) - 0.5*sigma_ln**2
    q = (np.arange(1, n+1)-0.5)/n
    z = math.sqrt(2)*erfinv(2*q-1)
    radii = np.exp(mu_ln + sigma_ln*z)
    wn = np.ones(n)/n
    wv = wn*radii**3
    wv /= wv.sum()
    return dict(R=radii, w_number=wn, w_volume=wv,
                R_number_mean=float(np.sum(wn*radii)),
                R_volume_mean=float(np.sum(wv*radii)), cv=cv)


def graphite_ocp_verbrugge(x):
    """Graphite OCP fit used in the original manuscript (Verbrugge et al.)."""
    x = np.clip(np.asarray(x, dtype=float), 1e-10, 1-1e-10)
    c = np.array([0.783536091577375, -58.461699380293744, 0.148099389333928,
        -0.040045422267324, 18.275366641133953, -0.169250626374014,
        -0.003688396507869, 24.422298845122281, -0.324145214809420,
        -5.714288636362947, 20.257336075941385, -0.580842687886653,
        5.692875412845519, 20.340933501171019, -0.580914902015057])
    return (c[0]*np.exp(c[1]*x)+c[2] + c[3]*np.tanh(c[4]*(x+c[5]))
            + c[6]*np.tanh(c[7]*(x+c[8])) + c[9]*np.tanh(c[10]*(x+c[11]))
            + c[12]*np.tanh(c[13]*(x+c[14])))



def graphite_diffusivity_baker_verbrugge(x, p):
    """Thermodynamic-factor graphite diffusivity sensitivity.

    Uses the Baker-Verbrugge form D(x) proportional to
    -x(1-x) F/(RT) dU/dx, normalized so D(0.5)=the reference Ds.
    It is used only as a sensitivity case, not as a cell-specific fit.
    """
    x=np.clip(np.asarray(x,dtype=float),1e-5,1-1e-5)
    h=2e-5
    xp=np.clip(x+h,1e-5,1-1e-5); xm=np.clip(x-h,1e-5,1-1e-5)
    dU=(graphite_ocp_verbrugge(xp)-graphite_ocp_verbrugge(xm))/(xp-xm)
    fac=-x*(1-x)*p['F']/(p['R']*p['T'])*dU
    x0=.5; xp0=x0+h; xm0=x0-h
    dU0=(float(graphite_ocp_verbrugge(xp0))-float(graphite_ocp_verbrugge(xm0)))/(xp0-xm0)
    fac0=-x0*(1-x0)*p['F']/(p['R']*p['T'])*dU0
    ratio=np.clip(fac/max(fac0,1e-8),0.05,20.0)
    return p['neg']['Ds']*ratio

def graphite_diffusivity_ecker2015(x, p=None):
    """Graphite solid diffusivity from the Ecker et al. parameterization.

    Reference-temperature (25 degC) fit:
        D_s(x) = 8.4e-13 exp(-11.3 x) + 8.2e-15  [m^2 s^-1].
    The present study is isothermal at approximately room temperature, so no
    additional Arrhenius temperature correction is applied in this sensitivity.
    """
    x=np.clip(np.asarray(x,dtype=float),0.0,1.0)
    return 8.4e-13*np.exp(-11.3*x)+8.2e-15


def lfp_ocp_regular(x, p, omega_rt=None):
    """Homogeneous regular-solution LFP equilibrium potential."""
    x = np.clip(np.asarray(x, dtype=float), p['num']['thermo_min'], 1-p['num']['thermo_min'])
    w = p['lfp']['Omega_RT_eff'] if omega_rt is None else np.asarray(omega_rt)
    RT = p['R']*p['T']
    return p['lfp']['U0'] + RT/p['F']*(np.log((1-x)/x) + w*(2*x-1))


def lfp_ocp_equilibrium(x, p):
    """Reference equilibrium LFP OCP with Maxwell plateau for balancing only."""
    x = np.clip(np.asarray(x, dtype=float), p['num']['thermo_min'], 1-p['num']['thermo_min'])
    u = lfp_ocp_regular(x, p).copy()
    lim = p['lfp']['limits_eff']
    if p['lfp']['Omega_RT_eff'] > 2:
        mask=(x > lim['xalpha']) & (x < lim['xbeta'])
        u=np.where(mask,p['lfp']['U0'],u)
    return u


def lfp_ocp_zk0d(x, direction, p):
    """Low-overpotential 0D phase-separation branch of Zelic & Katrasnik.

    direction > 0: LFP delithiation (cell charge)
    direction < 0: LFP lithiation (cell discharge)
    The final dimension may correspond to PSD bins, each with its own Omega(L).
    """
    x = np.clip(np.asarray(x, dtype=float), p['num']['x_min'], 1-p['num']['x_min'])
    d = np.sign(np.broadcast_to(direction, x.shape)).astype(float)
    d = np.where(d==0,1.0,d)
    if x.ndim >= 1 and x.shape[-1] == p['disc']['Npsd']:
        w = np.broadcast_to(np.asarray(p['lfp']['Omega_RT_bins']), x.shape)
        u = lfp_ocp_regular(x, p, w)
        for j, wj in enumerate(p['lfp']['Omega_RT_bins']):
            if wj <= 2:
                continue
            lim = p['lfp']['limits_bins'][j]
            xx = x[..., j]; dd = d[..., j]
            # Eq. 15: low-overpotential charge plateau x_alpha < x <= x_s2
            charge_plateau = (dd > 0) & (xx > lim['xalpha']) & (xx <= lim['xs2'])
            # Eq. 14: low-overpotential discharge plateau x_s1 < x <= x_beta
            discharge_plateau = (dd < 0) & (xx > lim['xs1']) & (xx <= lim['xbeta'])
            uj = u[..., j]
            uj[charge_plateau | discharge_plateau] = p['lfp']['U0']
            u[..., j] = uj
        return u
    # Scalar/reference version, used only for diagnostics.
    u = lfp_ocp_regular(x, p).copy()
    lim = p['lfp']['limits_eff']
    if p['lfp']['Omega_RT_eff'] > 2:
        charge_plateau = (d > 0) & (x > lim['xalpha']) & (x <= lim['xs2'])
        discharge_plateau = (d < 0) & (x > lim['xs1']) & (x <= lim['xbeta'])
        u=np.where(charge_plateau | discharge_plateau,p['lfp']['U0'],u)
    return u


def lfp_ocp_zk_high(x, p):
    """High-overpotential Zelic-Katrasnik limit (their Eq. 11).

    The average particle chemical potential follows the regular-solution
    spinodal relation and is independent of charge/discharge direction.  This
    is the appropriate limiting constitutive relation for the finite-current
    dynamic simulations in this study.  Each PSD bin uses its own Omega(L).
    """
    x = np.clip(np.asarray(x, dtype=float), p['num']['x_min'], 1-p['num']['x_min'])
    if x.ndim >= 1 and x.shape[-1] == p['disc']['Npsd']:
        w = np.broadcast_to(np.asarray(p['lfp']['Omega_RT_bins']), x.shape)
        return lfp_ocp_regular(x, p, w)
    return lfp_ocp_regular(x, p, p['lfp']['Omega_RT_eff'])


# ---------- Parameters and degradation ----------

def get_reference_params():
    """Representative literature-based LFP/graphite parameter set.

    Geometry/capacity parameters are mainly based on Prada et al. (2012).
    The LFP phase-separation relation is from Zelic & Katrasnik (2019), while
    graphite OCP follows Verbrugge et al. (2017). The set is deliberately a
    representative composite parameterization, not a parameterization of one
    named commercial cell.
    """
    p = dict(F=F, R=R_GAS, T=298.15, Vmin=2.50, Vmax=3.65)
    p['geom'] = dict(L_pos=80e-6, L_sep=25e-6, L_neg=34e-6)
    # Geometry and phase fractions follow the A123/ANR26650-oriented
    # parameterization reported by Prada et al. The active-material fraction
    # is the electrochemically active fraction; LAM creates an inactive-solid
    # fraction rather than artificially converting solid volume into pore volume.
    p['pos'] = dict(eps_s=.374, eps_f=.200, eps_e=.426, cmax=22806., j0_ref=.05)
    p['sep'] = dict(eps_e=.55)
    p['neg'] = dict(eps_s=.58, eps_f=.060, eps_e=.360, cmax=30555., R=5e-6,
                    j0_ref=.5, Ds=1e-14, Ds_model='constant')
    p['lfp'] = dict(R_mean=50e-9, psd_cv=.25, U0=3.422)
    p['elec'] = dict(c_ref=1200., c_init=1200., De=1.2e-10,
                     kappa=.78, t_plus=.36, brugg=1.5)
    p['R_contact'] = 0.0
    p['disc'] = dict(Nneg=10, Nsep=5, Npos=10, Npsd=13, Nr_neg=13)
    p['num'] = dict(x_min=2e-6, thermo_min=1e-12, balance_min=1e-10, ce_min=1., newton_tol=1e-9,
                    newton_max=18, branch_max=8, current_density_cap=2e4)
    # Literature coordinates are used only to initialize cyclable Li inventory
    # and the approximate 1C reference. They are NOT treated as fixed operating
    # limits once a different set of OCP functions is combined.
    p['balancing_reference'] = dict(xp_0=.7400, xn_0=.0132,
                                    xp_100=.0350, xn_100=.8110)
    p = update_derived_params(p)
    a = p['balancing_reference']
    q0 = p['Qp']*a['xp_0'] + p['Qn']*a['xn_0']
    q100 = p['Qp']*a['xp_100'] + p['Qn']*a['xn_100']
    p['QLi_fresh'] = .5*(q0+q100)
    p['QLi'] = p['QLi_fresh']
    p['Q_nominal_ref'] = .5*(p['Qp']*(a['xp_0']-a['xp_100']) +
                             p['Qn']*(a['xn_100']-a['xn_0']))
    p['deg'] = dict(mode='FRESH', severity=0.0, kinetic_coupling='decoupled')
    return p


def update_derived_params(p):
    p = copy.deepcopy(p)
    p['lfp']['psd'] = build_psd(p['lfp']['R_mean'], p['lfp']['psd_cv'], p['disc']['Npsd'])
    p['lfp']['Omega_RT_bins'] = omega_rt_from_particle_radius(p['lfp']['psd']['R'])
    p['lfp']['limits_bins'] = [compute_regular_solution_limits(float(w)) if w > 2 else
                              dict(xs1=np.nan,xs2=np.nan,xalpha=np.nan,xbeta=np.nan)
                              for w in p['lfp']['Omega_RT_bins']]
    # A smooth electrode-level equilibrium OCP is needed only for balancing and
    # low-rate capacity matching.  Rather than importing a second arbitrary
    # regular-solution parameter, use the volume-weighted interaction parameter
    # implied by the same particle-size distribution.  Dynamic particles retain
    # their individual Omega(L) values.
    p['lfp']['Omega_RT_eff'] = float(np.sum(p['lfp']['psd']['w_volume'] * p['lfp']['Omega_RT_bins']))
    p['lfp']['limits_eff'] = compute_regular_solution_limits(p['lfp']['Omega_RT_eff'])
    gn, gs, gp = p['geom']['L_neg'], p['geom']['L_sep'], p['geom']['L_pos']
    nn, ns, np_ = p['disc']['Nneg'], p['disc']['Nsep'], p['disc']['Npos']
    p['dx_neg'], p['dx_sep'], p['dx_pos'] = gn/nn, gs/ns, gp/np_
    p['dx_vec'] = np.r_[np.full(nn,p['dx_neg']), np.full(ns,p['dx_sep']), np.full(np_,p['dx_pos'])]
    p['eps_e_vec'] = np.r_[np.full(nn,p['neg']['eps_e']), np.full(ns,p['sep']['eps_e']), np.full(np_,p['pos']['eps_e'])]
    p['Nelec'] = len(p['dx_vec'])
    p['Qp'] = p['F']*p['pos']['eps_s']*gp*p['pos']['cmax']
    p['Qn'] = p['F']*p['neg']['eps_s']*gn*p['neg']['cmax']
    Rb = p['lfp']['psd']['R']; wv = p['lfp']['psd']['w_volume']
    p['pos']['a_s_bins'] = 3*p['pos']['eps_s']*(wv/Rb)
    p['pos']['a_s_total'] = float(np.sum(p['pos']['a_s_bins']))
    p['neg']['a_s'] = 3*p['neg']['eps_s']/p['neg']['R']
    nce = p['Nelec']; nx=np_*p['disc']['Npsd']; nr=p['disc']['Nr_neg']
    p['idx'] = dict(ce=slice(0,nce), xp=slice(nce,nce+nx), cn=slice(nce+nx,nce+nx+nr))
    p['Nstate'] = nce+nx+nr
    p['z_pos'] = (np.arange(np_)+.5)*p['dx_pos']
    return p


def make_degraded_cell(base, mode, severity, kinetic_coupling='decoupled'):
    """Synthetic degradation perturbations used to isolate causality.

    LLI removes cyclable lithium. LAM scales electrode active material volume.
    In the default 'decoupled' setting, j0_ref is rescaled to compensate the
    leading change in total exchange area, so the main comparison isolates
    thermodynamic/capacity effects from resistance growth.
    """
    p = copy.deepcopy(base)
    m = mode.upper().replace(' ','').replace('_','')
    s = max(0.0,float(severity))
    if m in ('FRESH','NONE'):
        pass
    elif m == 'LLI':
        p['QLi'] = base['QLi_fresh'] - s*base['Q_nominal_ref']
    elif m in ('LAMP','LAMPE','LAMPOS'):
        a0 = base['pos']['a_s_total']
        p['pos']['eps_s'] = base['pos']['eps_s']*(1-s)
        # Lost active material is treated as electrochemically inactive solid;
        # electrolyte porosity is held fixed so the default LAM perturbation does
        # not introduce an unintended transport change.
        p['pos']['eps_e'] = base['pos']['eps_e']
        p = update_derived_params(p)
        p['QLi'] = base['QLi_fresh']
        if kinetic_coupling == 'decoupled':
            p['pos']['j0_ref'] = base['pos']['j0_ref']*a0/p['pos']['a_s_total']
    elif m in ('LAMN','LAMNE','LAMNEG'):
        a0 = base['neg']['a_s']
        p['neg']['eps_s'] = base['neg']['eps_s']*(1-s)
        p['neg']['eps_e'] = base['neg']['eps_e']
        p = update_derived_params(p)
        p['QLi'] = base['QLi_fresh']
        if kinetic_coupling == 'decoupled':
            p['neg']['j0_ref'] = base['neg']['j0_ref']*a0/p['neg']['a_s']
    else:
        raise ValueError(mode)
    p['deg'] = dict(mode=m,severity=s,kinetic_coupling=kinetic_coupling)
    return p


def estimate_effective_asr(p):
    RT=p['R']*p['T']
    Rctn=RT/(p['F']*p['neg']['j0_ref']*p['neg']['a_s']*p['geom']['L_neg'])
    Rctp=RT/(p['F']*p['pos']['j0_ref']*p['pos']['a_s_total']*p['geom']['L_pos'])
    kn=p['elec']['kappa']*p['neg']['eps_e']**p['elec']['brugg']
    ks=p['elec']['kappa']*p['sep']['eps_e']**p['elec']['brugg']
    kp=p['elec']['kappa']*p['pos']['eps_e']**p['elec']['brugg']
    Re=p['geom']['L_neg']/(2*kn)+p['geom']['L_sep']/ks+p['geom']['L_pos']/(2*kp)
    return Rctn+Rctp+Re+p['R_contact']


# ---------- Equilibrium balancing helpers (internal, not a paper result) ----------

def fullcell_equilibrium_ocv(p, xp):
    scalar = np.ndim(xp)==0
    xp = np.atleast_1d(np.asarray(xp,dtype=float))
    xn = (p['QLi']-p['Qp']*xp)/p['Qn']
    valid=(xp>p['num']['balance_min'])&(xp<1-p['num']['balance_min'])&(xn>p['num']['balance_min'])&(xn<1-p['num']['balance_min'])
    V=np.full_like(xp,np.nan); Up=V.copy(); Un=V.copy()
    if np.any(valid):
        Up[valid]=lfp_ocp_equilibrium(xp[valid],p)
        Un[valid]=graphite_ocp_verbrugge(xn[valid])
        V[valid]=Up[valid]-Un[valid]
    if scalar:
        return float(V[0]),float(xn[0]),float(Up[0]),float(Un[0])
    return V,xn,Up,Un


def equilibrium_xp_at_voltage(p,Vtarget,side='low'):
    eps=p['num']['balance_min']
    xmin=max(eps,(p['QLi']-p['Qn']*(1-eps))/p['Qp'])
    xmax=min(1-eps,(p['QLi']-p['Qn']*eps)/p['Qp'])
    if xmax<=xmin: raise RuntimeError('No lithium-conserving interval')
    lin=np.linspace(xmin,xmax,4000)
    vals=fullcell_equilibrium_ocv(p,lin)[0]-Vtarget
    ids=np.where(np.isfinite(vals[:-1])&np.isfinite(vals[1:])&(vals[:-1]*vals[1:]<=0))[0]
    if len(ids)==0:
        # nearest internally valid point. This is used only to initialize a low-rate
        # characterization; the terminal cutoff itself is enforced dynamically.
        k=int(np.nanargmin(np.abs(vals)))
        return float(lin[k])
    j=ids[-1] if side=='low' else ids[0]
    return brentq(lambda z: fullcell_equilibrium_ocv(p,z)[0]-Vtarget,lin[j],lin[j+1])


# ---------- Fast 0D multiparticle characterization and parallel model ----------

def init_mp0d_at_voltage(p,Vtarget,side='low'):
    xp=equilibrium_xp_at_voltage(p,Vtarget,side)
    return np.full(p['disc']['Npsd'],xp,dtype=float)


def mp0d_xn_from_xp(xp,p):
    xbar=float(np.sum(p['lfp']['psd']['w_volume']*np.asarray(xp)))
    return (p['QLi']-p['Qp']*xbar)/p['Qn']


def _mp0d_positive_potential(xp,p,I):
    RT=p['R']*p['T']; direction=1.0 if I>=0 else -1.0
    Up=lfp_ocp_zk0d(xp,np.full_like(xp,direction),p)
    j0p=p['pos']['j0_ref']*2*np.sqrt(np.maximum(p['num']['x_min'],xp*(1-xp)))
    A=p['pos']['a_s_bins']*p['geom']['L_pos']
    blocked=((I>0)&(xp<=2*p['num']['x_min'])) | ((I<0)&(xp>=1-2*p['num']['x_min']))
    if np.all(blocked):
        phi=float(np.nanmax(Up)+5.0) if I>0 else float(np.nanmin(Up)-5.0)
        return phi,Up,np.zeros_like(xp),A
    def f(phi):
        arg=np.clip(p['F']*(phi-Up)/(2*RT),-30,30)
        ib=2*j0p*np.sinh(arg); ib=np.where(blocked,0.0,ib)
        return float(np.sum(A*ib)-I)
    lo=float(np.nanmin(Up)-1.5); hi=float(np.nanmax(Up)+1.5)
    flo,fhi=f(lo),f(hi)
    if flo*fhi>0:
        lo=float(np.nanmin(Up)-5); hi=float(np.nanmax(Up)+5)
    phi=brentq(f,lo,hi,maxiter=80)
    arg=np.clip(p['F']*(phi-Up)/(2*RT),-30,30)
    ibin=2*j0p*np.sinh(arg); ibin=np.where(blocked,0.0,ibin)
    return phi,Up,ibin,A


def mp0d_voltage_and_rates(state,p,Iapp,R_extra=0.0):
    xp=np.clip(np.asarray(state,dtype=float),p['num']['x_min'],1-p['num']['x_min'])
    xn=float(np.clip(mp0d_xn_from_xp(xp,p),p['num']['x_min'],1-p['num']['x_min']))
    phi,Up,ibin,A=_mp0d_positive_potential(xp,p,Iapp)
    Un=float(graphite_ocp_verbrugge(xn)); RT=p['R']*p['T']
    j0n=p['neg']['j0_ref']*2*math.sqrt(max(p['num']['x_min'],xn*(1-xn)))
    Rctn=RT/(p['F']*max(j0n,1e-15)*p['neg']['a_s']*p['geom']['L_neg'])
    kn=p['elec']['kappa']*p['neg']['eps_e']**p['elec']['brugg']; ks=p['elec']['kappa']*p['sep']['eps_e']**p['elec']['brugg']; kp=p['elec']['kappa']*p['pos']['eps_e']**p['elec']['brugg']
    Rohm=p['geom']['L_neg']/(2*kn)+p['geom']['L_sep']/ks+p['geom']['L_pos']/(2*kp)+p['R_contact']+R_extra
    V=phi-Un+Iapp*(Rctn+Rohm)
    dxp=-3*(ibin/p['F'])/(p['lfp']['psd']['R']*p['pos']['cmax'])
    # Frozen-state zero-net-current voltage, retaining the current-direction branch.
    direction=1.0 if Iapp>=0 else -1.0
    Up0=lfp_ocp_zk0d(xp,np.full_like(xp,direction),p)
    j0p=p['pos']['j0_ref']*2*np.sqrt(np.maximum(p['num']['x_min'],xp*(1-xp)))
    def f0(ph):
        ar=np.clip(p['F']*(ph-Up0)/(2*RT),-25,25)
        return float(np.sum(A*2*j0p*np.sinh(ar)))
    phi0=brentq(f0,float(np.nanmin(Up0)-.5),float(np.nanmax(Up0)+.5))
    Uzero=phi0-Un
    return V,dxp,dict(Up=Up,Un=Un,ibin=ibin,phi_p=phi,Rctn=Rctn,Rohm=Rohm,Uzero=Uzero,xn=xn)


def simulate_mp0d_halfcycle_fixed(p,C_rate=0.05,mode='charge',state0=None,dq_frac=5e-4,max_steps=12000,R_extra=0.0):
    sgn=1 if mode.lower()=='charge' else -1
    I1C=p['Q_nominal_ref']/3600.0; Iapp=sgn*C_rate*I1C
    if state0 is None:
        state0=init_mp0d_at_voltage(p,p['Vmin'] if sgn>0 else p['Vmax'],'low' if sgn>0 else 'high')
    x=np.array(state0,dtype=float); Vcut=p['Vmax'] if sgn>0 else p['Vmin']
    dQ=dq_frac*(p['Q_nominal_ref']/3600.0); dt=dQ*3600.0/max(abs(Iapp),1e-12)
    ts=[0.0]; states=[x.copy()]; vals=[mp0d_voltage_and_rates(x,p,Iapp,R_extra)]; reached=False
    for _ in range(max_steps):
        V,dx,_=vals[-1]
        if (sgn>0 and V>=Vcut) or (sgn<0 and V<=Vcut): reached=True; break
        pred=np.clip(x+dt*dx,p['num']['x_min'],1-p['num']['x_min'])
        _,dx2,_=mp0d_voltage_and_rates(pred,p,Iapp,R_extra)
        xnew=np.clip(x+.5*dt*(dx+dx2),p['num']['x_min'],1-p['num']['x_min'])
        vnew=mp0d_voltage_and_rates(xnew,p,Iapp,R_extra)
        crossed=(sgn>0 and vnew[0]>=Vcut>V) or (sgn<0 and vnew[0]<=Vcut<V)
        if crossed:
            delta=xnew-x
            fun=lambda ff: mp0d_voltage_and_rates(np.clip(x+ff*delta,p['num']['x_min'],1-p['num']['x_min']),p,Iapp,R_extra)[0]-Vcut
            try: frac=float(brentq(fun,0,1))
            except Exception: frac=float(np.clip((Vcut-V)/(vnew[0]-V),0,1))
            xcut=np.clip(x+frac*delta,p['num']['x_min'],1-p['num']['x_min'])
            ts.append(ts[-1]+frac*dt); states.append(xcut.copy()); vals.append(mp0d_voltage_and_rates(xcut,p,Iapp,R_extra)); reached=True; break
        x=xnew; ts.append(ts[-1]+dt); states.append(x.copy()); vals.append(vnew)
    V=np.array([v[0] for v in vals]); U0=np.array([v[2]['Uzero'] for v in vals]); xn=np.array([v[2]['xn'] for v in vals])
    t=np.array(ts); st=np.array(states); cap=abs(Iapp)*t[-1]/3600.0
    return dict(t=t,state=st,V=V,Uzero=U0,xn=xn,Iapp=Iapp,capacity_Ahm2=float(cap),reached_cutoff=reached,mode=mode,C_rate=C_rate)


def simulate_mp0d_cycle_fixed(p,C_rate=0.05,dq_frac=5e-4,R_extra=0.0):
    ch=simulate_mp0d_halfcycle_fixed(p,C_rate,'charge',None,dq_frac=dq_frac,R_extra=R_extra)
    ds=simulate_mp0d_halfcycle_fixed(p,C_rate,'discharge',ch['state'][-1],dq_frac=dq_frac,R_extra=R_extra)
    return ch,ds


def apparent_capacity(p,C_rate=0.05,dq_frac=1e-3):
    ch,ds=simulate_mp0d_cycle_fixed(p,C_rate=C_rate,dq_frac=dq_frac)
    return ds['capacity_Ahm2'],ch,ds

_CAP_CACHE={}
def apparent_capacity_cached(p,C_rate=0.05,dq_frac=1e-3):
    d=p.get('deg',{})
    key=(d.get('mode','FRESH'),round(float(d.get('severity',0)),7),p['disc']['Npsd'],round(p['lfp']['R_mean']*1e9,4),round(p['lfp']['psd_cv'],4),round(p['lfp']['Omega_RT_eff'],4),round(C_rate,5),round(dq_frac,7))
    if key not in _CAP_CACHE: _CAP_CACHE[key]=apparent_capacity(p,C_rate,dq_frac)[0]
    return _CAP_CACHE[key]


def match_capacity_lowrate(base,p_target,target_mode,bounds=(0,.40),C_rate=.05,dq_frac=1e-3):
    target=apparent_capacity_cached(p_target,C_rate,dq_frac)
    def f(s): return apparent_capacity_cached(make_degraded_cell(base,target_mode,s),C_rate,dq_frac)-target
    lo,hi=bounds; flo,fhi=f(lo),f(hi)
    if flo*fhi>0:
        r=minimize_scalar(lambda z: abs(f(z)),bounds=bounds,method='bounded',options={'xatol':2e-4}); sev=float(r.x)
    else: sev=float(brentq(f,lo,hi,xtol=2e-4))
    pm=make_degraded_cell(base,target_mode,sev); cm=apparent_capacity_cached(pm,C_rate,dq_frac)
    return pm,sev,dict(target_capacity=target,matched_capacity=cm,error_Ahm2=cm-target)


def init_mp0d_at_common_voltage(p,Vtarget,soc_hint=.35):
    xp=equilibrium_xp_at_voltage(p,Vtarget,'low' if soc_hint<.5 else 'high')
    return np.full(p['disc']['Npsd'],xp,dtype=float)


def parallel_mp0d_split(state1,state2,p1,p2,Iapp,Rextra1=0.,Rextra2=0.):
    def residual(I1):
        I2=Iapp-I1
        return mp0d_voltage_and_rates(state1,p1,I1,Rextra1)[0]-mp0d_voltage_and_rates(state2,p2,I2,Rextra2)[0]
    scale=max(abs(Iapp),1.0); lo,hi=-1.5*scale,2.5*scale; flo,fhi=residual(lo),residual(hi)
    for _ in range(5):
        if flo*fhi<=0: break
        lo-=2*scale; hi+=2*scale; flo,fhi=residual(lo),residual(hi)
    if flo*fhi>0:
        grid=np.linspace(lo,hi,101); rr=np.array([residual(z) for z in grid]); ids=np.where(rr[:-1]*rr[1:]<=0)[0]
        if len(ids): lo,hi=grid[ids[0]],grid[ids[0]+1]
        else:
            I1=float(grid[np.argmin(np.abs(rr))]); I2=Iapp-I1
            v1,d1,e1=mp0d_voltage_and_rates(state1,p1,I1,Rextra1); v2,d2,e2=mp0d_voltage_and_rates(state2,p2,I2,Rextra2)
            return .5*(v1+v2),np.array([I1,I2]),(d1,d2),(e1,e2)
    I1=float(brentq(residual,lo,hi,xtol=1e-8)); I2=Iapp-I1
    v1,d1,e1=mp0d_voltage_and_rates(state1,p1,I1,Rextra1); v2,d2,e2=mp0d_voltage_and_rates(state2,p2,I2,Rextra2)
    return .5*(v1+v2),np.array([I1,I2]),(d1,d2),(e1,e2)


def _state_on_lowrate_charge(p,Vtarget):
    ch=simulate_mp0d_halfcycle_fixed(p,.05,'charge',None,dq_frac=1e-3)
    k=int(np.argmin(np.abs(ch['V']-Vtarget)))
    return ch['state'][k].copy()


def simulate_parallel_mp0d_pair(p1,p2,C_rate,mode,initial_voltage=3.30,Rextra1=0.,Rextra2=0.,dq_frac=1.5e-3,max_steps=4000,capacity_mode='surrogate'):
    sgn=1 if mode.lower()=='charge' else -1
    if capacity_mode=='detailed':
        cap1=apparent_capacity_cached(p1); cap2=apparent_capacity_cached(p2)
    else:
        cap1=lowrate_capacity_surrogate(p1)[0]; cap2=lowrate_capacity_surrogate(p2)[0]
    Iapp=sgn*C_rate*(cap1+cap2)
    hint=.35 if sgn>0 else .75
    x1=init_mp0d_at_common_voltage(p1,initial_voltage,hint); x2=init_mp0d_at_common_voltage(p2,initial_voltage,hint)
    Vcut=max(p1['Vmax'],p2['Vmax']) if sgn>0 else min(p1['Vmin'],p2['Vmin'])
    dQ=dq_frac*((cap1+cap2)/2); dt=dQ*3600/max(abs(Iapp),1e-12)
    ts=[0.0]; X1=[x1.copy()]; X2=[x2.copy()]; vals=[]
    vals.append(parallel_mp0d_split(x1,x2,p1,p2,Iapp,Rextra1,Rextra2))
    for _ in range(max_steps):
        V,I,_,_=vals[-1]
        if (sgn>0 and V>=Vcut) or (sgn<0 and V<=Vcut): break
        _,_,(d1,d2),_=parallel_mp0d_split(x1,x2,p1,p2,Iapp,Rextra1,Rextra2)
        a1=np.clip(x1+dt*d1,p1['num']['x_min'],1-p1['num']['x_min']); a2=np.clip(x2+dt*d2,p2['num']['x_min'],1-p2['num']['x_min'])
        _,_,(e1,e2),_=parallel_mp0d_split(a1,a2,p1,p2,Iapp,Rextra1,Rextra2)
        x1=np.clip(x1+.5*dt*(d1+e1),p1['num']['x_min'],1-p1['num']['x_min']); x2=np.clip(x2+.5*dt*(d2+e2),p2['num']['x_min'],1-p2['num']['x_min'])
        ts.append(ts[-1]+dt); X1.append(x1.copy()); X2.append(x2.copy()); vals.append(parallel_mp0d_split(x1,x2,p1,p2,Iapp,Rextra1,Rextra2))
    V=np.array([z[0] for z in vals]); I=np.array([z[1] for z in vals]); Uzero=np.array([[z[3][0]['Uzero'],z[3][1]['Uzero']] for z in vals])
    return dict(t=np.asarray(ts),V=V,I=I,Uzero=Uzero,state1=np.asarray(X1),state2=np.asarray(X2),Iapp=Iapp,mode=mode)

def compute_current_metrics(t,I,Iapp=None):
    d=I[:,0]-I[:,1]; T=max(t[-1]-t[0],np.finfo(float).eps)
    rms=float(np.sqrt(np.trapz(d*d,t)/T)); peak=float(np.max(np.abs(d)))
    qex=float(.5*np.trapz(np.abs(d),t)/3600)
    out=dict(I_rms_mismatch=rms,I_peak_mismatch=peak,Q_excess_Ahm2=qex)
    if Iapp is not None and abs(Iapp)>1e-12:
        out['M_peak']=peak/abs(Iapp)
        out['M_rms']=rms/abs(Iapp)
    else:
        out['M_peak']=np.nan; out['M_rms']=np.nan
    return out


# ---------- Full SPMe-like multiparticle model ----------

def unpack_cell_state(y,p):
    ce=y[p['idx']['ce']]
    xp=y[p['idx']['xp']].reshape((p['disc']['Npos'],p['disc']['Npsd']))
    cn=y[p['idx']['cn']]
    nn,ns=p['disc']['Nneg'],p['disc']['Nsep']
    return dict(ce=ce,xp=xp,cn=cn,ce_neg=ce[:nn],ce_sep=ce[nn:nn+ns],ce_pos=ce[-p['disc']['Npos']:])


def spherical_diffusion_rhs(c,D,Rp,J_out,D_nodes=None):
    N=len(c); rf=np.linspace(0,Rp,N+1); rc=.5*(rf[:-1]+rf[1:])
    Vsh=4*np.pi/3*(rf[1:]**3-rf[:-1]**3); Af=4*np.pi*rf**2
    Nface=np.zeros(N+1)
    if D_nodes is None:
        Df=np.full(N-1,float(D)); Dsurf=float(D)
    else:
        D_nodes=np.asarray(D_nodes,dtype=float)
        Df=2*D_nodes[:-1]*D_nodes[1:]/np.maximum(D_nodes[:-1]+D_nodes[1:],np.finfo(float).eps)
        Dsurf=float(D_nodes[-1])
    Nface[1:N]=-Df*np.diff(c)/np.diff(rc); Nface[-1]=J_out
    dc=-(Af[1:]*Nface[1:]-Af[:-1]*Nface[:-1])/Vsh
    cs=c[-1]-J_out*(Rp-rc[-1])/max(Dsurf,np.finfo(float).eps)
    return dc,cs


def electrolyte_rhs(ce,source,p):
    eps=p['eps_e_vec']; Dcell=p['elec']['De']*eps**p['elec']['brugg']; N=len(ce); J=np.zeros(N+1)
    for k in range(N-1):
        dist=.5*p['dx_vec'][k]+.5*p['dx_vec'][k+1]
        Df=2*Dcell[k]*Dcell[k+1]/(Dcell[k]+Dcell[k+1])
        J[k+1]=-Df*(ce[k+1]-ce[k])/dist
    div=(J[1:]-J[:-1])/p['dx_vec']
    return (-div+source)/eps


def cell_at_voltage(y,p,Vcell):
    s=unpack_cell_state(y,p); RT=p['R']*p['T']
    ce_n=max(float(np.mean(s['ce_neg'])),p['num']['ce_min'])
    xn_s=float(np.clip(s['cn'][-1]/p['neg']['cmax'],p['num']['x_min'],1-p['num']['x_min']))
    Un=float(graphite_ocp_verbrugge(xn_s))
    j0n=p['neg']['j0_ref']*2*math.sqrt(max(p['num']['x_min'],xn_s*(1-xn_s)))*math.sqrt(ce_n/p['elec']['c_ref'])
    Rctn=RT/(p['F']*max(j0n,1e-12)*p['neg']['a_s']*p['geom']['L_neg'])
    kn=p['elec']['kappa']*p['neg']['eps_e']**p['elec']['brugg']; ks=p['elec']['kappa']*p['sep']['eps_e']**p['elec']['brugg']; kp=p['elec']['kappa']*p['pos']['eps_e']**p['elec']['brugg']
    Rbase=p['geom']['L_neg']/(2*kn)+p['geom']['L_sep']/ks
    Rohm=Rbase+p['z_pos']/kp; Rseries=Rctn+Rohm+p['R_contact']
    ce_p=np.maximum(s['ce_pos'],p['num']['ce_min'])
    dPhi=2*RT/p['F']*(1-p['elec']['t_plus'])*np.log(ce_p/ce_n)
    Npos,Npsd=p['disc']['Npos'],p['disc']['Npsd']
    ce_mat=np.repeat(ce_p[:,None],Npsd,axis=1); Rmat=np.repeat(Rseries[:,None],Npsd,axis=1); dpm=np.repeat(dPhi[:,None],Npsd,axis=1)
    Aweight=p['dx_pos']*np.repeat(p['pos']['a_s_bins'][None,:],Npos,axis=0)
    x=np.clip(s['xp'],p['num']['x_min'],1-p['num']['x_min'])
    j0p=p['pos']['j0_ref']*2*np.sqrt(np.maximum(p['num']['x_min'],x*(1-x)))*np.sqrt(ce_mat/p['elec']['c_ref'])
    # The finite-current simulations use the Zelic--Katrasnik high-overpotential
    # constitutive limit (Eq. 11), which is independent of charge/discharge
    # direction. Only composition-bound blocking is iterated here.
    blocked=np.zeros_like(x,dtype=bool); I=0.0
    def solve_fixed(Iguess,eta0,blocked):
        for _ in range(p['num']['newton_max']):
            eta=eta0-Iguess*Rmat; arg=np.clip(p['F']*eta/(2*RT),-18,18)
            ia=2*j0p*np.sinh(arg); ia[blocked]=0
            Icalc=float(np.sum(Aweight*ia)); did=j0p*(p['F']/RT)*np.cosh(arg); did[blocked]=0
            df=1+float(np.sum(Aweight*did*Rmat)); Inew=Iguess-(Iguess-Icalc)/max(df,1e-12)
            if abs(Inew-Iguess)<=p['num']['newton_tol']*max(1,abs(Inew)):
                Iguess=Inew; break
            Iguess=Inew
        eta=eta0-Iguess*Rmat; arg=np.clip(p['F']*eta/(2*RT),-18,18)
        ia=2*j0p*np.sinh(arg); ia[blocked]=0; did=j0p*(p['F']/RT)*np.cosh(arg); did[blocked]=0
        return Iguess,ia,did,eta
    for _ in range(p['num']['branch_max']):
        Up=lfp_ocp_zk_high(x,p); eta0=Vcell+Un-Up-dpm; I,ia,did,eta=solve_fixed(I,eta0,blocked)
        new_block=((x<=2*p['num']['x_min'])&(ia>0)) | ((x>=1-2*p['num']['x_min'])&(ia<0))
        if np.array_equal(new_block,blocked):
            break
        blocked=new_block
    Up=lfp_ocp_zk_high(x,p); eta0=Vcell+Un-Up-dpm; I,ia,did,eta=solve_fixed(I,eta0,blocked)
    num=float(np.sum(Aweight*did)); den=1+float(np.sum(Aweight*did*Rmat)); dIdV=num/max(den,1e-12)
    jmol=ia/p['F']; dxp=-3*jmol/np.repeat(p['lfp']['psd']['R'][None,:],Npos,axis=0)/p['pos']['cmax']
    Jneg=-I/(p['F']*p['neg']['a_s']*p['geom']['L_neg'])
    model_Ds=p['neg'].get('Ds_model','constant')
    if model_Ds=='baker_verbrugge':
        Dnodes=graphite_diffusivity_baker_verbrugge(np.clip(s['cn']/p['neg']['cmax'],p['num']['x_min'],1-p['num']['x_min']),p)
        dcn,cs=spherical_diffusion_rhs(s['cn'],p['neg']['Ds'],p['neg']['R'],Jneg,D_nodes=Dnodes)
    elif model_Ds=='ecker2015':
        Dnodes=graphite_diffusivity_ecker2015(np.clip(s['cn']/p['neg']['cmax'],p['num']['x_min'],1-p['num']['x_min']),p)
        dcn,cs=spherical_diffusion_rhs(s['cn'],p['neg']['Ds'],p['neg']['R'],Jneg,D_nodes=Dnodes)
    else:
        dcn,cs=spherical_diffusion_rhs(s['cn'],p['neg']['Ds'],p['neg']['R'],Jneg)
    srcn=(1-p['elec']['t_plus'])*p['neg']['a_s']*Jneg*np.ones(p['disc']['Nneg']); srcs=np.zeros(p['disc']['Nsep'])
    srcp=(1-p['elec']['t_plus'])*np.sum(np.repeat(p['pos']['a_s_bins'][None,:],Npos,axis=0)*jmol,axis=1)
    dce=electrolyte_rhs(s['ce'],np.r_[srcn,srcs,srcp],p)
    dy=np.zeros(p['Nstate']); dy[p['idx']['ce']]=dce; dy[p['idx']['xp']]=dxp.ravel(); dy[p['idx']['cn']]=dcn
    return dict(dy=dy,I=I,dIdV=dIdV,Up=Up,Un=Un,eta_p=eta,i_p=ia,dir_p=np.sign(ia),
                xn_surface=float(np.clip(cs/p['neg']['cmax'],p['num']['x_min'],1-p['num']['x_min'])),Rct_n=Rctn,Rohm=Rohm)


def solve_parallel_voltage(t,y,cells,current_fun,Vguess=None):
    slices=[]; k=0
    for p in cells: slices.append(slice(k,k+p['Nstate'])); k+=p['Nstate']
    Iapp=current_fun(t)
    if Vguess is None: Vguess=3.3
    def er(V):
        ev=[cell_at_voltage(y[sl],p,V) for sl,p in zip(slices,cells)]
        I=np.array([e['I'] for e in ev]); d=np.array([e['dIdV'] for e in ev])
        return float(I.sum()-Iapp),float(d.sum()),I,ev
    V=float(np.clip(Vguess,2.0,4.1))
    for _ in range(12):
        res,dr,I,ev=er(V)
        if abs(res)<1e-8*max(1,abs(Iapp)): return V,I,ev
        if not np.isfinite(dr) or abs(dr)<1e-12: break
        Vn=float(np.clip(V-res/dr,2.0,4.1))
        if abs(Vn-V)<1e-10: V=Vn; break
        V=Vn
    grid=np.linspace(2.0,4.1,80); rr=np.array([er(v)[0] for v in grid]); ids=np.where(rr[:-1]*rr[1:]<=0)[0]
    if len(ids): V=brentq(lambda z: er(z)[0],grid[ids[0]],grid[ids[0]+1])
    else: V=float(grid[np.argmin(abs(rr))])
    _,_,I,ev=er(V); return V,I,ev


def state_from_xp(p,xp):
    xn=(p['QLi']-p['Qp']*xp)/p['Qn']
    ce=np.full(p['Nelec'],p['elec']['c_init'])
    xpstate=np.full((p['disc']['Npos'],p['disc']['Npsd']),xp)
    cn=np.full(p['disc']['Nr_neg'],xn*p['neg']['cmax'])
    return np.r_[ce,xpstate.ravel(),cn]


def init_cell_at_ocv(p,Vtarget,soc_hint=.4):
    # Search all valid equilibrium states and prefer the root nearest the hint.
    eps=p['num']['x_min']; xmin=max(eps,(p['QLi']-p['Qn']*(1-eps))/p['Qp']); xmax=min(1-eps,(p['QLi']-p['Qn']*eps)/p['Qp'])
    grid=np.linspace(xmin,xmax,5000); V=fullcell_equilibrium_ocv(p,grid)[0]; err=np.abs(V-Vtarget)
    k=int(np.nanargmin(err+1e-4*np.abs(np.linspace(0,1,len(grid))-soc_hint)))
    xp=float(grid[k]); return state_from_xp(p,xp),dict(xp=xp,V=float(V[k]),error=float(V[k]-Vtarget))


def init_parallel_at_common_ocv(cells,Vtarget,soc_hint=.4):
    ys=[]; infos=[]
    for p in cells:
        y,i=init_cell_at_ocv(p,Vtarget,soc_hint); ys.append(y); infos.append(i)
    return np.concatenate(ys),infos


def simulate_cc_halfcycle(cells,y0,C_rate,mode,max_step=5.,rtol=4e-5,atol=3e-7,max_time_factor=1.6,capacity_rate=0.05):
    # Define 1C from the same low-rate terminal-voltage capacity protocol used
    # for cell matching. This avoids mixing a metastable-particle capacity with
    # the macroscopic capacity definition.
    caps=[lowrate_capacity(p,capacity_rate) for p in cells]
    Iapp=(1 if mode.lower()=='charge' else -1)*C_rate*sum(caps)
    current=lambda t:Iapp; sgn=1 if Iapp>0 else -1; Vcut=max(p['Vmax'] for p in cells) if sgn>0 else min(p['Vmin'] for p in cells)
    last=[3.3]
    def rhs(t,y):
        V,I,ev=solve_parallel_voltage(t,y,cells,current,last[0]); last[0]=V
        return np.concatenate([e['dy'] for e in ev])
    def event(t,y): return solve_parallel_voltage(t,y,cells,current,last[0])[0]-Vcut
    event.terminal=True; event.direction=sgn
    sol=solve_ivp(rhs,(0,max_time_factor*3600/max(C_rate,1e-4)),y0,method='BDF',rtol=rtol,atol=atol,max_step=max_step,events=event)
    V=[]; II=[]; vg=3.3
    for tt,yy in zip(sol.t,sol.y.T):
        v,i,_=solve_parallel_voltage(tt,yy,cells,current,vg); vg=v; V.append(v); II.append(i)
    return dict(t=sol.t,y=sol.y.T,V=np.asarray(V),I=np.asarray(II),Iapp=Iapp,success=sol.success,message=sol.message)


def apply_parameter_variant(p,name,value):
    p=copy.deepcopy(p); name=name.lower()
    if name=='rmean_nm': p['lfp']['R_mean']=value*1e-9
    elif name=='psd_cv': p['lfp']['psd_cv']=value
    elif name=='omega_rt':
        raise ValueError('Omega is particle-size dependent in V6; vary particle size/PSD instead')
    elif name=='ds_neg': p['neg']['Ds']=value
    elif name=='j0_pos_mult': p['pos']['j0_ref']*=value
    elif name=='j0_neg_mult': p['neg']['j0_ref']*=value
    elif name=='kappa': p['elec']['kappa']=value
    elif name=='de': p['elec']['De']=value
    elif name=='rcontact': p['R_contact']=value
    else: raise ValueError(name)
    return update_derived_params(p)

# ---------- Low-rate characterization between terminal-voltage cutoffs ----------

def lowrate_ocvr_characterization(p, C_rate=0.05, n_curve=600):
    """Low-rate capacity/terminal-voltage characterization.

    Uses the equilibrium (Maxwell-constructed) LFP OCP and a state-dependent
    charge-transfer + electrolyte ASR. This diagnostic is used only for
    electrode balancing and capacity matching; the direction-dependent
    Zelic-Katrasnik branches are reserved for the multiparticle dynamics.
    """
    eps=p['num']['balance_min']
    xmin=max(eps,(p['QLi']-p['Qn']*(1-eps))/p['Qp'])
    xmax=min(1-eps,(p['QLi']-p['Qn']*eps)/p['Qp'])
    if xmax <= xmin: raise RuntimeError('No lithium-conserving composition interval')
    Iabs=C_rate*p['Q_nominal_ref']/3600.0
    RT=p['R']*p['T']
    kn=p['elec']['kappa']*p['neg']['eps_e']**p['elec']['brugg']
    ks=p['elec']['kappa']*p['sep']['eps_e']**p['elec']['brugg']
    kp=p['elec']['kappa']*p['pos']['eps_e']**p['elec']['brugg']
    Re=p['geom']['L_neg']/(2*kn)+p['geom']['L_sep']/ks+p['geom']['L_pos']/(2*kp)+p['R_contact']

    def UR(x):
        xa=np.asarray(x,dtype=float)
        xac=np.clip(xa,eps,1-eps)
        xn=np.clip((p['QLi']-p['Qp']*xac)/p['Qn'],eps,1-eps)
        U=lfp_ocp_equilibrium(xac,p)-graphite_ocp_verbrugge(xn)
        j0n=p['neg']['j0_ref']*2*np.sqrt(np.maximum(eps,xn*(1-xn)))
        j0p=p['pos']['j0_ref']*2*np.sqrt(np.maximum(eps,xac*(1-xac)))
        Rn=RT/(p['F']*j0n*p['neg']['a_s']*p['geom']['L_neg'])
        Rp=RT/(p['F']*j0p*p['pos']['a_s_total']*p['geom']['L_pos'])
        return U,Rn+Rp+Re

    # Linear bulk grid plus logarithmic resolution near both composition bounds.
    d=xmax-xmin
    lin=np.linspace(xmin,xmax,1800)
    edge=np.geomspace(1e-10,1,700)
    g=np.unique(np.r_[lin,xmin+d*edge,xmax-d*edge]); g=g[(g>=xmin)&(g<=xmax)]; g.sort()
    Ug,Rg=UR(g)
    Vcg=Ug+Iabs*Rg; Vdg=Ug-Iabs*Rg

    def select_root(vals,target,which):
        z=vals-target
        ids=np.where(np.isfinite(z[:-1])&np.isfinite(z[1:])&(z[:-1]*z[1:]<=0))[0]
        if len(ids)==0: raise RuntimeError('Low-rate terminal-voltage cutoff root not found')
        j=ids[0] if which=='first' else ids[-1]
        def f(x,sgn):
            u,r=UR(float(x)); return float(u+sgn*Iabs*r-target)
        sgn=+1 if vals is Vcg else -1
        return float(brentq(lambda x:f(x,sgn),g[j],g[j+1],xtol=1e-13))

    # xp decreases during charge. The high-SOC cutoff is the smallest charge
    # root; the low-SOC cutoff is the largest discharge root.
    xp_hi=select_root(Vcg,p['Vmax'],'first')
    xp_lo=select_root(Vdg,p['Vmin'],'last')
    if xp_lo <= xp_hi: raise RuntimeError('Invalid low-rate operating window')
    cap=float(p['Qp']*(xp_lo-xp_hi)/3600.0)
    xp_charge=np.linspace(xp_lo,xp_hi,n_curve); xp_discharge=np.linspace(xp_hi,xp_lo,n_curve)
    Uc,Rc=UR(xp_charge); Ud,Rd=UR(xp_discharge)
    V_charge=Uc+Iabs*Rc; V_discharge=Ud-Iabs*Rd
    q_charge=p['Qp']*(xp_lo-xp_charge)/3600.0; q_discharge=p['Qp']*(xp_discharge-xp_hi)/3600.0
    xn_hi=float((p['QLi']-p['Qp']*xp_hi)/p['Qn']); xn_lo=float((p['QLi']-p['Qp']*xp_lo)/p['Qn'])
    return dict(capacity_Ahm2=cap,xp_high=xp_hi,xp_low=xp_lo,xn_high=xn_hi,xn_low=xn_lo,Iabs=Iabs,
                q_charge=q_charge,V_charge=np.asarray(V_charge),q_discharge=q_discharge,V_discharge=np.asarray(V_discharge),
                xp_charge=xp_charge,xp_discharge=xp_discharge)

def lowrate_capacity(p, C_rate=0.05):
    return lowrate_ocvr_characterization(p,C_rate=C_rate,n_curve=80)['capacity_Ahm2']


def match_capacity_lowrate_ocvr(base,p_target,target_mode,bounds=(0,.5),C_rate=.05):
    target=lowrate_capacity(p_target,C_rate)
    f=lambda s: lowrate_capacity(make_degraded_cell(base,target_mode,s),C_rate)-target
    lo,hi=bounds; flo,fhi=f(lo),f(hi)
    if flo*fhi <= 0:
        sev=float(brentq(f,lo,hi,xtol=1e-8))
    else:
        sev=float(minimize_scalar(lambda z:abs(f(z)),bounds=bounds,method='bounded',options={'xatol':1e-7}).x)
    pm=make_degraded_cell(base,target_mode,sev)
    cm=lowrate_capacity(pm,C_rate)
    return pm,sev,dict(target_capacity=target,matched_capacity=cm,error_Ahm2=cm-target)

# ---------- Fast low-rate capacity surrogate for dense degradation maps ----------
def lowrate_capacity_surrogate(p):
    """Fast deterministic low-rate capacity used in dense sweep maps.

    This now uses the same terminal-voltage-cutoff OCV-R characterization as
    the central capacity-matching analysis, avoiding fixed stoichiometric
    endpoints and the former composition-bound surrogate.
    """
    c=lowrate_ocvr_characterization(p,C_rate=.05,n_curve=40)
    return c['capacity_Ahm2'],dict(xp_low=c['xp_low'],xp_high=c['xp_high'],
                                   xn_low=c['xn_low'],xn_high=c['xn_high'])

def match_capacity_surrogate(base,p_target,target_mode,bounds=(0,.50)):
    target=lowrate_capacity_surrogate(p_target)[0]
    f=lambda s: lowrate_capacity_surrogate(make_degraded_cell(base,target_mode,s))[0]-target
    lo,hi=bounds; flo,fhi=f(lo),f(hi)
    if flo*fhi<=0: sev=float(brentq(f,lo,hi,xtol=1e-6))
    else: sev=float(minimize_scalar(lambda z:abs(f(z)),bounds=bounds,method='bounded').x)
    pm=make_degraded_cell(base,target_mode,sev); cm=lowrate_capacity_surrogate(pm)[0]
    return pm,sev,dict(target_capacity=target,matched_capacity=cm,error_Ahm2=cm-target)

# ---------- Very fast OCV-R model for dense sweeps ----------
def scalar_cell_ocv(p,xp,direction):
    xn=(p['QLi']-p['Qp']*xp)/p['Qn']
    if xn<=p['num']['balance_min'] or xn>=1-p['num']['balance_min'] or xp<=p['num']['balance_min'] or xp>=1-p['num']['balance_min']:
        # still evaluate at clipped bounds to retain the steep thermodynamic asymptote
        xn=float(np.clip(xn,p['num']['balance_min'],1-p['num']['balance_min']))
    return float(lfp_ocp_equilibrium(np.array(float(np.clip(xp,p['num']['balance_min'],1-p['num']['balance_min']))),p)-graphite_ocp_verbrugge(xn))


def scalar_xp_at_voltage(p,Vtarget,direction,soc_hint=.4):
    eps=p['num']['balance_min']; xmin=max(eps,(p['QLi']-p['Qn']*(1-eps))/p['Qp']); xmax=min(1-eps,(p['QLi']-p['Qn']*eps)/p['Qp'])
    # combine linear grid with logarithmic resolution near both boundaries
    lin=np.linspace(xmin,xmax,5000)
    lo=np.geomspace(max(xmin,eps),min(xmax,2e-2),1200) if xmin<2e-2 else np.array([])
    hi=1-np.geomspace(max(1-xmax,eps),min(1-xmin,2e-2),1200) if xmax>0.98 else np.array([])
    g=np.unique(np.r_[lin,lo,hi]); g=g[(g>=xmin)&(g<=xmax)]; g.sort()
    xn=(p['QLi']-p['Qp']*g)/p['Qn']; xnc=np.clip(xn,p['num']['balance_min'],1-p['num']['balance_min'])
    v=lfp_ocp_equilibrium(g,p)-graphite_ocp_verbrugge(xnc)-Vtarget
    ids=np.where(v[:-1]*v[1:]<=0)[0]
    if len(ids):
        # choose root closest to requested normalized position
        qs=(xmax-g[ids])/(xmax-xmin); j=ids[np.argmin(abs(qs-soc_hint))]
        return float(brentq(lambda x:scalar_cell_ocv(p,x,direction)-Vtarget,g[j],g[j+1]))
    return float(g[np.argmin(abs(v))])


def simulate_ocvr_pair_fast(p1,p2,C_rate,mode,initial_voltage=3.30,Rextra1=0.,Rextra2=0.,dq_frac=5e-4,max_steps=6000):
    sgn=1 if mode.lower()=='charge' else -1
    cap1=lowrate_capacity_surrogate(p1)[0]; cap2=lowrate_capacity_surrogate(p2)[0]
    Iapp=sgn*C_rate*(cap1+cap2)
    R1=estimate_effective_asr(p1)+Rextra1; R2=estimate_effective_asr(p2)+Rextra2
    hint=.35 if sgn>0 else .75
    x1=scalar_xp_at_voltage(p1,initial_voltage,sgn,hint); x2=scalar_xp_at_voltage(p2,initial_voltage,sgn,hint)
    Vcut=max(p1['Vmax'],p2['Vmax']) if sgn>0 else min(p1['Vmin'],p2['Vmin'])
    dQ=dq_frac*.5*(cap1+cap2); dt=dQ*3600/max(abs(Iapp),1e-12)
    ts=[]; X=[]; Is=[]; Vs=[]; Us=[]
    for k in range(max_steps):
        U1=scalar_cell_ocv(p1,x1,sgn); U2=scalar_cell_ocv(p2,x2,sgn)
        I1=(U2-U1+R2*Iapp)/(R1+R2); I2=Iapp-I1
        V=U1+R1*I1
        ts.append(k*dt); X.append([x1,x2]); Is.append([I1,I2]); Vs.append(V); Us.append([U1,U2])
        if (sgn>0 and V>=Vcut) or (sgn<0 and V<=Vcut): break
        x1=float(np.clip(x1-dt*I1/p1['Qp'],p1['num']['x_min'],1-p1['num']['x_min']))
        x2=float(np.clip(x2-dt*I2/p2['Qp'],p2['num']['x_min'],1-p2['num']['x_min']))
    return dict(t=np.asarray(ts),xp=np.asarray(X),I=np.asarray(Is),V=np.asarray(Vs),U=np.asarray(Us),Iapp=Iapp,R=np.array([R1,R2]),mode=mode)

def scalar_effective_asr(p,xp,R_extra=0.0):
    xn=float(np.clip((p['QLi']-p['Qp']*xp)/p['Qn'],p['num']['balance_min'],1-p['num']['balance_min']))
    xp=float(np.clip(xp,p['num']['balance_min'],1-p['num']['balance_min']))
    RT=p['R']*p['T']
    j0n=p['neg']['j0_ref']*2*math.sqrt(max(p['num']['balance_min'],xn*(1-xn)))
    j0p=p['pos']['j0_ref']*2*math.sqrt(max(p['num']['balance_min'],xp*(1-xp)))
    Rn=RT/(p['F']*max(j0n,1e-15)*p['neg']['a_s']*p['geom']['L_neg'])
    Rp=RT/(p['F']*max(j0p,1e-15)*p['pos']['a_s_total']*p['geom']['L_pos'])
    kn=p['elec']['kappa']*p['neg']['eps_e']**p['elec']['brugg']; ks=p['elec']['kappa']*p['sep']['eps_e']**p['elec']['brugg']; kp=p['elec']['kappa']*p['pos']['eps_e']**p['elec']['brugg']
    Re=p['geom']['L_neg']/(2*kn)+p['geom']['L_sep']/ks+p['geom']['L_pos']/(2*kp)
    return Rn+Rp+Re+p['R_contact']+R_extra


def simulate_ocvr_pair_fast_stateR(p1,p2,C_rate,mode,initial_voltage=3.30,Rextra1=0.,Rextra2=0.,dq_frac=5e-4,max_steps=6000,cap1=None,cap2=None,x1_init=None,x2_init=None):
    sgn=1 if mode.lower()=='charge' else -1
    if cap1 is None: cap1=lowrate_capacity_surrogate(p1)[0]
    if cap2 is None: cap2=lowrate_capacity_surrogate(p2)[0]
    Iapp=sgn*C_rate*(cap1+cap2); hint=.35 if sgn>0 else .75
    x1=scalar_xp_at_voltage(p1,initial_voltage,sgn,hint) if x1_init is None else float(x1_init)
    x2=scalar_xp_at_voltage(p2,initial_voltage,sgn,hint) if x2_init is None else float(x2_init)
    Vcut=max(p1['Vmax'],p2['Vmax']) if sgn>0 else min(p1['Vmin'],p2['Vmin'])
    dQ=dq_frac*.5*(cap1+cap2); dt=dQ*3600/max(abs(Iapp),1e-12)
    ts=[]; X=[]; Is=[]; Vs=[]; Us=[]; Rs=[]
    for k in range(max_steps):
        U1=scalar_cell_ocv(p1,x1,sgn); U2=scalar_cell_ocv(p2,x2,sgn)
        R1=scalar_effective_asr(p1,x1,Rextra1); R2=scalar_effective_asr(p2,x2,Rextra2)
        I1=(U2-U1+R2*Iapp)/(R1+R2); I2=Iapp-I1; V=U1+R1*I1
        ts.append(k*dt); X.append([x1,x2]); Is.append([I1,I2]); Vs.append(V); Us.append([U1,U2]); Rs.append([R1,R2])
        if (sgn>0 and V>=Vcut) or (sgn<0 and V<=Vcut): break
        x1=float(np.clip(x1-dt*I1/p1['Qp'],p1['num']['x_min'],1-p1['num']['x_min']))
        x2=float(np.clip(x2-dt*I2/p2['Qp'],p2['num']['x_min'],1-p2['num']['x_min']))
    return dict(t=np.asarray(ts),xp=np.asarray(X),I=np.asarray(Is),V=np.asarray(Vs),U=np.asarray(Us),R=np.asarray(Rs),Iapp=Iapp,mode=mode)

# ---------- Mixed degradation helper (V8) ----------
def make_mixed_degraded_cell(base, lli=0.0, lamn=0.0, lamp=0.0, kinetic_coupling='decoupled'):
    """Apply simultaneous LLI, LAMn and LAMp to a representative cell.

    Parameters are fractional severities (0.10 = 10%). LLI removes cyclable
    lithium relative to the fresh reference inventory. LAM reduces the active
    material volume fraction. In ``decoupled`` mode the reference exchange
    current density is rescaled so the leading-order product j0*a_s is retained,
    isolating thermodynamic/capacity effects. In ``coupled`` mode j0_ref is left
    unchanged, so LAM naturally reduces specific surface area and raises the
    charge-transfer contribution to branch resistance.
    """
    p = copy.deepcopy(base)
    lli=max(0.0,float(lli)); lamn=max(0.0,float(lamn)); lamp=max(0.0,float(lamp))
    if any(v>=0.95 for v in (lamn,lamp)):
        raise ValueError('LAM severity must remain below 95%')
    a0n=base['neg']['a_s']; a0p=base['pos']['a_s_total']
    p['neg']['eps_s']=base['neg']['eps_s']*(1-lamn)
    p['pos']['eps_s']=base['pos']['eps_s']*(1-lamp)
    # Keep electrolyte porosity fixed: lost active solid is treated as inactive
    # solid so LAM does not silently introduce a pore-transport perturbation.
    p['neg']['eps_e']=base['neg']['eps_e']; p['pos']['eps_e']=base['pos']['eps_e']
    p=update_derived_params(p)
    p['QLi_fresh']=base['QLi_fresh']
    p['Q_nominal_ref']=base['Q_nominal_ref']
    p['QLi']=base['QLi_fresh']-lli*base['Q_nominal_ref']
    p['pos']['j0_ref']=base['pos']['j0_ref']
    p['neg']['j0_ref']=base['neg']['j0_ref']
    if kinetic_coupling == 'decoupled':
        if lamp>0: p['pos']['j0_ref']=base['pos']['j0_ref']*a0p/max(p['pos']['a_s_total'],1e-30)
        if lamn>0: p['neg']['j0_ref']=base['neg']['j0_ref']*a0n/max(p['neg']['a_s'],1e-30)
    elif kinetic_coupling != 'coupled':
        raise ValueError("kinetic_coupling must be 'decoupled' or 'coupled'")
    p['deg']=dict(mode='MIXED',severity=max(lli,lamn,lamp),LLI=lli,LAMn=lamn,LAMp=lamp,
                  kinetic_coupling=kinetic_coupling)
    return p


def capacity_difference_fraction(p1,p2,C_rate=0.05):
    q1=lowrate_capacity(p1,C_rate); q2=lowrate_capacity(p2,C_rate)
    return (q2-q1)/(0.5*(q1+q2)),q1,q2
