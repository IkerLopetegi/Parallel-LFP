from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from analysis import run_all as r
if __name__=='__main__':
    r.OUT=r.ROOT/'results_v6_new'
    r.figure4_robustness(r.m.get_reference_params())
