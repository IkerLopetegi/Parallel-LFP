from pathlib import Path
import sys,time,json
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import lfp_parallel.model as m
import analysis.run_all as r
label=sys.argv[1]; key=sys.argv[2]; v=float(sys.argv[3]); idx=sys.argv[4]
b=m.get_reference_params(); b=r.make_grid(b,4,2,4,5,7)
vv=v*1e-3 if key=='rcontact' else v
b=m.apply_parameter_variant(b,key,vv)
p1=m.make_degraded_cell(b,'LLI',r.S_LLI); p2=m.make_degraded_cell(b,'LAMn',r.S_LAMN)
y,_=m.init_parallel_at_common_ocv([p1,p2],3.30,.4)
t0=time.time(); sol=m.simulate_cc_halfcycle([p1,p2],y,1.0,'charge',max_step=18,rtol=2e-4,atol=2e-6,max_time_factor=1.0)
met=m.compute_current_metrics(sol['t'],sol['I'],sol['Iapp']); qmean=.5*(m.lowrate_capacity_surrogate(p1)[0]+m.lowrate_capacity_surrogate(p2)[0])
out=dict(Parameter=label,Value=v,M_peak=met['M_peak'],M_rms=met['M_rms'],Qex_norm=met['Q_excess_Ahm2']/qmean,Duration_min=sol['t'][-1]/60,success=bool(sol['success']),runtime_s=time.time()-t0)
d=Path('results/robust_tmp');d.mkdir(parents=True,exist_ok=True);(d/f'{idx}.json').write_text(json.dumps(out));print(out)
